
"use strict";

let SimpleMove = require('./SimpleMove.js')

module.exports = {
  SimpleMove: SimpleMove,
};
